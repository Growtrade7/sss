# Gujrati Trader — separated files

## Structure

- `index.html` — page markup + Meta Pixel base code
- `css/styles.css` — all page styling
- `js/tracking.js` — Meta Subscribe + Telegram click tracking
- `js/profit-feed.js` — live profit-feed UI

## Conversion rule implemented

A browser/device profile gets at most one Meta `Subscribe` event:

1. First `JOIN FREE TELEGRAM` click:
   - fires `Subscribe`
   - stores a local deduplication flag
   - opens Telegram normally
2. Later clicks from the same browser/device:
   - do not fire another `Subscribe`
   - may still fire `TelegramJoinClick` as a diagnostic click event

## Important limitation

This is browser-side deduplication. It is not a guaranteed physical-device or human-level identity system.

The limit can be bypassed/reset by:
- clearing browser site data
- private/incognito browsing
- another browser
- another device
- browser storage restrictions

If you need a hard one-person/one-device rule across these cases, use a backend/server-side deduplication system.

## Measurement direction

This setup prevents repeated button clicks from inflating Meta `Subscribe`.
It does not artificially create Telegram requests or guarantee that Telegram requests are real people.

So, for example, 10 unique website Subscribe conversions and 40 Telegram requests can occur without treating the extra Telegram requests as 30 additional Meta conversions.

The reverse should not be "fixed" by fabricating Meta conversions; the proper approach is to investigate attribution, tracking loss, consent, redirects, and Telegram-side request data.
