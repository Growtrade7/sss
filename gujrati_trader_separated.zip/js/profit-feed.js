lucide.createIcons();

const profitBox = document.getElementById("profitBox");

const names = [
  "Rajesh","Priya","Anil","Kiran","Neha","Suresh","Divya","Vikram",
  "Pooja","Ravi","Sneha","Amit","Deepa","Karthik","Megha","Arjun"
];

const callTypes = [
  "NIFTY CALL","BANKNIFTY PUT","RELIANCE CE","TCS PE",
  "HDFCBANK CALL","INFY PUT","OPTION BUY","INTRADAY"
];

const colors = [
  "linear-gradient(135deg,#1e3a8a,#5b8def)",
  "linear-gradient(135deg,#7c2d12,#f59e0b)",
  "linear-gradient(135deg,#065f46,#22c55e)",
  "linear-gradient(135deg,#4c1d95,#a855f7)",
  "linear-gradient(135deg,#831843,#ec4899)",
  "linear-gradient(135deg,#0c4a6e,#06b6d4)"
];

function rand(min, max) {
  return Math.random() * (max - min) + min;
}

function generateProfit() {
  const name = names[Math.floor(Math.random() * names.length)];
  const initials = name.charAt(0).toUpperCase();
  const amount = rand(2500, 18000).toFixed(2);
  const call = callTypes[Math.floor(Math.random() * callTypes.length)];
  const color = colors[Math.floor(Math.random() * colors.length)];
  const timeAgo = Math.floor(rand(1, 9));

  const entry = document.createElement("div");
  entry.classList.add("profit-entry");

  entry.innerHTML = `
    <div class="user">
      <div class="avatar" style="background:${color}">${initials}</div>
      <div class="info">
        <div class="name">${name}</div>
        <div class="meta">
          <i data-lucide="tag"></i> ${call} &nbsp;•&nbsp;
          <i data-lucide="clock"></i> ${timeAgo}m ago
        </div>
      </div>
    </div>
    <div class="profit-amount">
      <i data-lucide="arrow-up-right"></i>
      +₹${amount}
    </div>
  `;

  profitBox.prepend(entry);
  lucide.createIcons();

  while (profitBox.childElementCount > 5) {
    profitBox.removeChild(profitBox.lastChild);
  }
}

for (let i = 0; i < 3; i++) {
  generateProfit();
}

setInterval(generateProfit, 2000);
