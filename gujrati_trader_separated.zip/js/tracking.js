/*
 * Meta/Telegram conversion tracking
 *
 * IMPORTANT:
 * - One browser/device profile can fire the website Subscribe event only once.
 * - Repeated clicks on JOIN FREE TELEGRAM do NOT create another Subscribe event.
 * - localStorage is browser-scoped, so clearing site data, private browsing, or
 *   another browser/device can create a new client identifier.
 * - For a true cross-device/person-level limit, use a backend with a server-side ID.
 */

const TRACKING_KEYS = {
  deviceId: 'gt_device_id_v1',
  subscribeSent: 'gt_subscribe_sent_v1'
};

function getOrCreateDeviceId() {
  let id = localStorage.getItem(TRACKING_KEYS.deviceId);

  if (!id) {
    id = (crypto.randomUUID
      ? crypto.randomUUID()
      : 'gt-' + Date.now() + '-' + Math.random().toString(36).slice(2));

    localStorage.setItem(TRACKING_KEYS.deviceId, id);
  }

  return id;
}

function isSubscribeAlreadySent() {
  return localStorage.getItem(TRACKING_KEYS.subscribeSent) === '1';
}

function markSubscribeSent() {
  localStorage.setItem(TRACKING_KEYS.subscribeSent, '1');
}

/*
 * Fires Meta's standard Subscribe event only once per browser/device profile.
 * We intentionally do not fire Subscribe again on repeated Telegram clicks.
 */
function trackUniqueTelegramSubscribe(location) {
  if (isSubscribeAlreadySent()) {
    return false;
  }

  if (typeof fbq !== 'function') {
    return false;
  }

  const deviceId = getOrCreateDeviceId();

  fbq('track', 'Subscribe', {
    content_name: 'Telegram Join',
    content_category: 'Conversion',
    source: 'website',
    placement: location || 'unknown',
    device_token: deviceId
  });

  markSubscribeSent();
  return true;
}

/*
 * Optional diagnostic event for clicks.
 * This is NOT the Subscribe conversion and is not used for deduplication.
 * Keep it if you want to analyze repeated clicks separately.
 */
function trackTelegramClick(location) {
  if (typeof fbq !== 'function') {
    return;
  }

  fbq('trackCustom', 'TelegramJoinClick', {
    cta_location: location || 'unknown'
  });
}

document.querySelectorAll('.tg-cta').forEach(function (btn) {
  btn.addEventListener('click', function () {
    const location = btn.getAttribute('data-cta-location') || 'unknown';

    // Unique conversion: max one Subscribe per browser/device storage.
    trackUniqueTelegramSubscribe(location);

    // Raw click diagnostic: can happen multiple times.
    trackTelegramClick(location);
  });
});

setTimeout(function () {
  if (typeof fbq === 'function') {
    fbq('trackCustom', 'Engaged15s', {});
  }
}, 15000);
